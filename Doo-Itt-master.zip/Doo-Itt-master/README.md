[![HitCount](http://hits.dwyl.com/ridsuteri/Doo-Itt.svg)](http://hits.dwyl.com/ridsuteri/Doo-Itt)

# TODO APP

A simple Todo Web App made using Express

# How to use

1. Get NodeJs on your System.
2. Clone this repository .
3. Open in terminal/cmd
4. Do npm install
5. Go to Web Browser and hit https://localhost:8000


# Specifications

1. You can add task (with priority ,due-date and category tags) 
2. All the Tasks are stored and fetched from MongoDB 
3. You can delete single/multiple tasks by selecting them via chekboxes 

# Made using 

1. Node Js
2. Express
3. MongoDB
4. Bootstrap

# Screenshots

<img src='snaps/img-1.png'>
<img src='snaps/img-2.png'>
<img src='snaps/img-3.png'>

